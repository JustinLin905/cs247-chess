#ifndef SAMPLE_BOARDS_H
#define SAMPLE_BOARDS_H

#include <array>
#include <vector>

enum class SampleBoards {
    DEFAULT,
    TEST_CHECKMATE,
    TEST_STALEMATE,
};

// class SampleBoard {
//    public:
//     static std::array<std::array<char, 8>, 8> getBoard(SampleBoards board) {
//         switch (board) {
//             case SampleBoards::DEFAULT:
//                 return {{'r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'},
//                         {'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p

#endif